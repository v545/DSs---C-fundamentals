#include <stdio.h>
struct info{
	int credit;
	char id[10],name[30];
	
}data;
struct subject{
	char datastructure;
	char computernetworks;
}mark;
int value(char t){
	int a;
	switch(t) {
		case 'a':
			a=4;
			return a;
			break;
		case 'b':
			a=3;
			return a;
			break;
		case 'c':
			a=2;
			return a;
			break;
		case 'd':
			a=1;
			return a;
			break;
		default:
			printf('invalid grade');
	}
}
int main(){
	int i;
	data.credit=4;
	for(i=0;i<2;i++){	
		printf("enter an id\n");
		scanf("%s",data.id);
		printf("enter a name\n");
		scanf("%s",data.name);
		scanf("%c",&mark.datastructure);
		printf("enter grade of datastructure\n");
		scanf("%c",&mark.datastructure);
		float valueD=value(mark.datastructure);
		scanf("%c",&mark.computernetworks);
		printf("enter grade of computernetworks\n");
		scanf("%c",&mark.computernetworks);
		float valueC=value(mark.computernetworks);
		float result=((valueD*data.credit)+(valueC*data.credit))/8;
		printf("the result is = %f\n",result);
	}
	
}
